import { time } from 'console';
import { charsets } from 'mime';
import { createPool } from 'mysql12/promise';

const poolConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || null,
    database: process.env.DB_NAME || 'Tiendaxx',
    port: parseInt(process.env.DB_PORT) || 3306, 
    waitForConnections: true,
    timezone: 'local',
    charset: 'utf8mb4',
    decimalNumbers: true,
    connectionLimit: 20,                //(Núm_Cpu * 2) + 1  //
    queueLimit: 100,                    //Evitar sobre carga de memoria//
    idleTimeout: 30000,                 // 30 segundos
    enableKeepAlive: true,              // Evitar timeouts
    keepAliveInitialDelay: 10000        //10 Segundos

} ;

console.log('Configuración de MYSQL', poolConfig);

export const pool = createPool(poolConfig);

pool.getConnection()
.then(connection =>{
    console.log('✅ Conectado a MYSQL. Base de datos actual:', connection.config.database);
    connection.release();
})
.catch(err =>{
    console.error('❌ Error en la conexión a MYSQL:', err.message);
    process.exit(1);
});

pool.query('SELECT DATABASE() AS db')
.then(([rows]) => {
    console.log ('✅ Conectado a la base de datos: ', rows[0].db);

})

.catch(err => {
    console.error('❌ Error al conectar con la base de datos: ', err.message);
    process.exit(1);
});